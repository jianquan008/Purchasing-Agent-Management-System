import express from 'express';
import { getDatabase } from '../database/init';
import { authenticateToken, AuthRequest, requireAdmin } from '../middleware/auth';

const router = express.Router();

// 获取库存列表
router.get('/list', authenticateToken, (req: AuthRequest, res) => {
  const db = getDatabase();
  
  db.all('SELECT * FROM inventory ORDER BY item_name', (err, inventory) => {
    db.close();
    if (err) {
      return res.status(500).json({ error: '获取库存失败' });
    }
    res.json(inventory);
  });
});

// 更新库存 (仅管理员)
router.put('/:id', authenticateToken, requireAdmin, (req: AuthRequest, res) => {
  const { id } = req.params;
  const { current_stock, unit_price } = req.body;
  
  const db = getDatabase();
  
  db.run(
    'UPDATE inventory SET current_stock = ?, unit_price = ?, last_updated = CURRENT_TIMESTAMP WHERE id = ?',
    [current_stock, unit_price, id],
    function(err) {
      db.close();
      if (err) {
        return res.status(500).json({ error: '更新库存失败' });
      }
      
      if (this.changes === 0) {
        return res.status(404).json({ error: '库存项目不存在' });
      }
      
      res.json({ message: '库存更新成功' });
    }
  );
});

// 删除库存项目 (仅管理员)
router.delete('/:id', authenticateToken, requireAdmin, (req: AuthRequest, res) => {
  const { id } = req.params;
  const db = getDatabase();
  
  db.run('DELETE FROM inventory WHERE id = ?', [id], function(err) {
    db.close();
    if (err) {
      return res.status(500).json({ error: '删除库存失败' });
    }
    
    if (this.changes === 0) {
      return res.status(404).json({ error: '库存项目不存在' });
    }
    
    res.json({ message: '库存删除成功' });
  });
});

// 获取库存统计
router.get('/stats', authenticateToken, (req: AuthRequest, res) => {
  const db = getDatabase();
  
  db.all(`
    SELECT 
      COUNT(*) as total_items,
      SUM(current_stock) as total_stock,
      SUM(current_stock * unit_price) as total_value
    FROM inventory
  `, (err, stats) => {
    db.close();
    if (err) {
      return res.status(500).json({ error: '获取库存统计失败' });
    }
    res.json(stats[0]);
  });
});

export default router;