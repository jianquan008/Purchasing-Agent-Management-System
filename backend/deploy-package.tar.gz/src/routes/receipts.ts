import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import Tesseract from 'tesseract.js';
import { getDatabase } from '../database/init';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

// 配置文件上传
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = process.env.UPLOAD_PATH || './uploads';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'receipt-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('只支持图片文件'));
    }
  }
});

// OCR识别收据
router.post('/ocr', authenticateToken, upload.single('receipt'), async (req: AuthRequest, res) => {
  if (!req.file) {
    return res.status(400).json({ error: '请上传收据图片' });
  }

  try {
    const { data: { text } } = await Tesseract.recognize(req.file.path, 'chi_sim+eng');
    
    // 简单的文本解析逻辑 (可以根据实际收据格式优化)
    const items = parseReceiptText(text);
    
    res.json({
      imagePath: req.file.filename,
      ocrText: text,
      parsedItems: items
    });
  } catch (error) {
    console.error('OCR识别失败:', error);
    res.status(500).json({ error: 'OCR识别失败' });
  }
});

// 保存收据数据
router.post('/save', authenticateToken, async (req: AuthRequest, res) => {
  const { imagePath, items, totalAmount } = req.body;
  
  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: '收据项目不能为空' });
  }

  const db = getDatabase();
  
  db.serialize(() => {
    db.run('BEGIN TRANSACTION');
    
    // 插入收据记录
    db.run(
      'INSERT INTO receipts (user_id, image_path, total_amount) VALUES (?, ?, ?)',
      [req.user!.id, imagePath, totalAmount],
      function(err) {
        if (err) {
          db.run('ROLLBACK');
          db.close();
          return res.status(500).json({ error: '保存收据失败' });
        }
        
        const receiptId = this.lastID;
        
        // 插入收据项目
        const stmt = db.prepare('INSERT INTO receipt_items (receipt_id, item_name, unit_price, quantity, total_price) VALUES (?, ?, ?, ?, ?)');
        
        items.forEach((item: any) => {
          stmt.run([receiptId, item.name, item.unitPrice, item.quantity, item.totalPrice]);
          
          // 更新库存
          db.run(`
            INSERT INTO inventory (item_name, current_stock, unit_price) 
            VALUES (?, ?, ?)
            ON CONFLICT(item_name) DO UPDATE SET
              current_stock = current_stock + ?,
              unit_price = ?,
              last_updated = CURRENT_TIMESTAMP
          `, [item.name, item.quantity, item.unitPrice, item.quantity, item.unitPrice]);
        });
        
        stmt.finalize();
        
        db.run('COMMIT', (err) => {
          db.close();
          if (err) {
            return res.status(500).json({ error: '保存失败' });
          }
          res.json({ message: '收据保存成功', receiptId });
        });
      }
    );
  });
});

// 获取收据列表
router.get('/list', authenticateToken, (req: AuthRequest, res) => {
  const db = getDatabase();
  
  db.all(`
    SELECT r.*, u.username 
    FROM receipts r 
    JOIN users u ON r.user_id = u.id 
    ORDER BY r.created_at DESC
  `, (err, receipts) => {
    db.close();
    if (err) {
      return res.status(500).json({ error: '获取收据列表失败' });
    }
    res.json(receipts);
  });
});

// 获取收据详情
router.get('/:id', authenticateToken, (req: AuthRequest, res) => {
  const receiptId = req.params.id;
  const db = getDatabase();
  
  db.get('SELECT * FROM receipts WHERE id = ?', [receiptId], (err, receipt) => {
    if (err) {
      db.close();
      return res.status(500).json({ error: '获取收据失败' });
    }
    
    if (!receipt) {
      db.close();
      return res.status(404).json({ error: '收据不存在' });
    }
    
    db.all('SELECT * FROM receipt_items WHERE receipt_id = ?', [receiptId], (err, items) => {
      db.close();
      if (err) {
        return res.status(500).json({ error: '获取收据项目失败' });
      }
      
      res.json({ ...receipt, items });
    });
  });
});

// 简单的收据文本解析函数
function parseReceiptText(text: string) {
  const lines = text.split('\n').filter(line => line.trim());
  const items = [];
  
  // 这里是一个简化的解析逻辑，实际应用中需要根据具体收据格式调整
  for (const line of lines) {
    // 尝试匹配包含数字的行，可能是商品信息
    const match = line.match(/(.+?)\s+(\d+(?:\.\d+)?)\s+(\d+)\s+(\d+(?:\.\d+)?)/);
    if (match) {
      items.push({
        name: match[1].trim(),
        unitPrice: parseFloat(match[2]),
        quantity: parseInt(match[3]),
        totalPrice: parseFloat(match[4])
      });
    }
  }
  
  return items;
}

export default router;